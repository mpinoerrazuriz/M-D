(() => {
  const STORAGE_KEY = "md_data_v1";
  const PIN_KEY = "md_pin_hash_v1";
  const PIN_SALT_KEY = "md_pin_salt_v1";
  const START_DATE_DEFAULT = "2026-01-23";

  const $ = (sel, root=document) => root.querySelector(sel);
  const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));

  // ---------- helpers ----------
  function safeParse(json, fallback){ try{return JSON.parse(json);}catch{ return fallback; } }
  function uuid(){ return (crypto.randomUUID?crypto.randomUUID(): (Date.now().toString(36)+Math.random().toString(36).slice(2))); }
  function nowISODate(){ const d=new Date(); const tz=d.getTimezoneOffset()*60000; return new Date(d.getTime()-tz).toISOString().slice(0,10); }
  function escapeHtml(s){ return (s??"").toString().replace(/[&<>"']/g, c=>({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;" }[c])); }
  function escapeAttr(s){ return escapeHtml(s).replace(/"/g,"&quot;"); }
  function formatDate(iso){ try{ const [y,m,d]=iso.split("-"); return `${d}-${m}-${y}`;}catch{ return iso; } }
  function daysTogether(startISO){
    const start = new Date(startISO + "T00:00:00");
    const today = new Date();
    return Math.max(0, Math.floor((today.getTime()-start.getTime())/86400000));
  }

  // toast
  let toastTimer=null;
  function toast(msg){
    const el=$("#toast"); if(!el) return;
    el.textContent=msg;
    el.classList.remove("hidden");
    clearTimeout(toastTimer);
    toastTimer=setTimeout(()=>el.classList.add("hidden"), 2400);
  }

  // crypto pin
  function getSalt(){
    let salt = localStorage.getItem(PIN_SALT_KEY);
    if(!salt){
      const u=crypto.getRandomValues(new Uint8Array(16));
      salt=Array.from(u).map(b=>b.toString(16).padStart(2,"0")).join("");
      localStorage.setItem(PIN_SALT_KEY, salt);
    }
    return salt;
  }
  async function sha256Hex(str){
    const enc=new TextEncoder().encode(str);
    const buf=await crypto.subtle.digest("SHA-256", enc);
    return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,"0")).join("");
  }
  async function pinHash(pin){ return await sha256Hex(`${getSalt()}:${pin}`); }

  function defaultData(){
    return {
      meta:{
        createdAt:new Date().toISOString(),
        updatedAt:new Date().toISOString(),
        startDate:START_DATE_DEFAULT,
        partners:{a:"Martina", b:"Diego"}
      },
      travels:{ international:[], national:[] },
      dates:{ ideas:[], dayByDay:[] },
      goals:[],
      notes:[]
    };
  }
  function loadData(){
    const raw=localStorage.getItem(STORAGE_KEY);
    const data = raw ? safeParse(raw, defaultData()) : defaultData();
    if(!data.meta) data.meta=defaultData().meta;
    if(!data.meta.startDate) data.meta.startDate=START_DATE_DEFAULT;
    if(!data.meta.partners) data.meta.partners={a:"Martina", b:"Diego"};
    if(!data.travels) data.travels={international:[], national:[]};
    if(!data.dates) data.dates={ideas:[], dayByDay:[]};
    if(!data.goals) data.goals=[];
    if(!data.notes) data.notes=[];
    return data;
  }
  function saveData(data){
    data.meta.updatedAt=new Date().toISOString();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }

  const state={
    unlocked:false,
    data:loadData(),
    activeTab:"home",
    subTab:{travels:"international", dates:"ideas"}
  };

  // ---------- UI render ----------
  function navTab(key,label){
    const active = state.activeTab===key ? "active": "";
    return `<button class="tab ${active}" data-tab="${key}">${label}</button>`;
  }

  function partnerSelectOptions(includeBoth=false){
    const a=escapeHtml(state.data.meta.partners.a||"Martina");
    const b=escapeHtml(state.data.meta.partners.b||"Diego");
    let opts = includeBoth ? `<option value="Ambos">Ambos</option>` : "";
    opts += `<option value="${a}">${a}</option><option value="${b}">${b}</option>`;
    return opts;
  }

  function summaryItem(title, meta, goTab){
    return `
      <div class="item">
        <div class="top">
          <div>
            <div class="name">${escapeHtml(title)}</div>
            <div class="meta">${escapeHtml(meta)}</div>
          </div>
          <button class="btn" data-goto="${goTab}">Abrir</button>
        </div>
      </div>`;
  }

  function renderHome(){
    const intl=state.data.travels.international.length;
    const nat=state.data.travels.national.length;
    const ideas=state.data.dates.ideas.length;
    const plans=state.data.dates.dayByDay.length;
    const goals=state.data.goals.length;
    return `
      <h2>Home</h2>
      <p>Un lugar simple para planear viajes, dates y metas juntos.</p>
      <div class="section">
        <div class="list">
          ${summaryItem("🌍 Viajes internacionales", `${intl} guardados`, "travels")}
          ${summaryItem("🇨🇱 Viajes nacionales", `${nat} guardados`, "travels")}
          ${summaryItem("💡 Ideas de dates", `${ideas} ideas`, "dates")}
          ${summaryItem("🗓️ Plan día a día", `${plans} planes`, "dates")}
          ${summaryItem("🎯 Metas de pareja", `${goals} metas`, "goals")}
        </div>
      </div>
      <div class="section">
        <h2>Extra</h2>
        <p>Agregué “Notas” para guardar listas (restaurantes, regalos, películas).</p>
      </div>
    `;
  }

  function renderTravels(){
    const sub=state.subTab.travels||"international";
    const list=sub==="international" ? state.data.travels.international : state.data.travels.national;
    const title=sub==="international"?"Viajes internacionales":"Viajes nacionales";
    const placeholder=sub==="international"?"Ej: Japón, Italia, NYC":"Ej: San Pedro, Puerto Varas";
    const partnerOptions=partnerSelectOptions(true);

    const items = list.length ? list.map(x=>`
      <div class="item">
        <div class="top">
          <div>
            <div class="name">${escapeHtml(x.dest)} <span class="chip">${escapeHtml(x.priority)}</span></div>
            <div class="meta">${escapeHtml(x.when||"Sin fecha")} • ${escapeHtml(x.who||"Ambos")} • ${escapeHtml(x.budget||"Sin presupuesto")}</div>
          </div>
          <div class="btns">
            <button class="btn danger" data-del="travel" data-sub="${sub}" data-id="${x.id}">Borrar</button>
          </div>
        </div>
        ${x.note?`<div class="note">${escapeHtml(x.note)}</div>`:""}
      </div>`).join("") : `<p class="small">Aún no hay destinos. Agrega el primero arriba.</p>`;

    return `
      <h2>Viajes</h2>
      <p>Wishlist de lugares, presupuestos y detalles clave.</p>
      <div class="section tabs">
        <button class="tab ${sub==="international"?"active":""}" data-subtrav="international">🌍 Internacional</button>
        <button class="tab ${sub==="national"?"active":""}" data-subtrav="national">🇨🇱 Nacional</button>
      </div>

      <div class="section">
        <h2>${escapeHtml(title)}</h2>
        <div class="form">
          <div class="row two">
            <div class="field">
              <label>Destino</label>
              <input id="trav_dest" placeholder="${escapeAttr(placeholder)}" />
            </div>
            <div class="field">
              <label>Prioridad</label>
              <select id="trav_priority">
                <option value="Alta">Alta</option>
                <option value="Media" selected>Media</option>
                <option value="Baja">Baja</option>
              </select>
            </div>
          </div>

          <div class="row three">
            <div class="field"><label>Ideal (mes/año)</label><input id="trav_when" placeholder="Ej: Oct 2026" /></div>
            <div class="field"><label>Presupuesto aprox</label><input id="trav_budget" placeholder="Ej: USD 3.000 / $1.200.000" /></div>
            <div class="field"><label>Quién</label><select id="trav_who">${partnerOptions}</select></div>
          </div>

          <div class="field"><label>Notas</label><textarea id="trav_note" placeholder="Ideas, links, cosas por hacer, etc."></textarea></div>
          <button class="btn primary" id="btnAddTravel" data-sub="${sub}">Agregar</button>
        </div>

        <div class="list">${items}</div>
      </div>
    `;
  }

  function renderDates(){
    const sub=state.subTab.dates||"ideas";
    return `
      <h2>Dates</h2>
      <p>Ideas, panoramas y planificación día a día.</p>
      <div class="section tabs">
        <button class="tab ${sub==="ideas"?"active":""}" data-subdates="ideas">💡 Ideas</button>
        <button class="tab ${sub==="dayByDay"?"active":""}" data-subdates="dayByDay">🗓️ Día a día</button>
      </div>
      <div class="section">
        ${sub==="ideas" ? renderDateIdeas() : renderDayByDay()}
      </div>
    `;
  }

  function renderDateIdeas(){
    const list=state.data.dates.ideas;
    const partnerOptions=partnerSelectOptions(true);
    const items=list.length ? list.map(x=>`
      <div class="item">
        <div class="top">
          <div>
            <div class="name">${escapeHtml(x.title)} <span class="chip">${escapeHtml(x.type)}</span></div>
            <div class="meta">${escapeHtml(x.when||"Sin fecha")} • ${escapeHtml(x.budget||"Sin presupuesto")} • Propone: ${escapeHtml(x.by||"Ambos")}</div>
          </div>
          <div class="btns">
            <button class="btn danger" data-del="idea" data-id="${x.id}">Borrar</button>
          </div>
        </div>
        ${x.note?`<div class="note">${escapeHtml(x.note)}</div>`:""}
      </div>`).join("") : `<p class="small">No hay ideas aún. Agrega una arriba.</p>`;

    return `
      <h2>Ideas</h2>
      <div class="form">
        <div class="row two">
          <div class="field"><label>Idea / Panorama</label><input id="idea_title" placeholder="Ej: picnic, sushi night, cine" /></div>
          <div class="field">
            <label>Tipo</label>
            <select id="idea_type">
              <option value="Romántico">Romántico</option>
              <option value="Aventura">Aventura</option>
              <option value="Comida" selected>Comida</option>
              <option value="Cultura">Cultura</option>
              <option value="Relax">Relax</option>
              <option value="Casero">Casero</option>
              <option value="Otro">Otro</option>
            </select>
          </div>
        </div>
        <div class="row three">
          <div class="field"><label>Presupuesto</label><input id="idea_budget" placeholder="Ej: $30.000" /></div>
          <div class="field"><label>Cuándo</label><input id="idea_when" placeholder="Ej: viernes" /></div>
          <div class="field"><label>Quién propone</label><select id="idea_by">${partnerOptions}</select></div>
        </div>
        <div class="field"><label>Notas</label><textarea id="idea_note" placeholder="Detalles, links, lugar..."></textarea></div>
        <button class="btn primary" id="btnAddIdea">Agregar</button>
      </div>

      <div class="list">${items}</div>
    `;
  }

  function renderDayByDay(){
    const list=state.data.dates.dayByDay;
    const partnerOptions=partnerSelectOptions(true);
    const items=list.length ? [...list].sort((a,b)=>a.date<b.date?-1:1).map(x=>`
      <div class="item">
        <div class="top">
          <div>
            <div class="name">${escapeHtml(formatDate(x.date))} — ${escapeHtml(x.title||"Plan")}</div>
            <div class="meta">Arma: ${escapeHtml(x.who||"Ambos")} • Tags: ${escapeHtml((x.tags||[]).join(", ")||"—")}</div>
          </div>
          <div class="btns">
            <button class="btn danger" data-del="plan" data-id="${x.id}">Borrar</button>
          </div>
        </div>
        ${x.plan?`<div class="note">${escapeHtml(x.plan)}</div>`:""}
      </div>`).join("") : `<p class="small">No hay planes aún. Agrega uno arriba.</p>`;

    return `
      <h2>Día a día</h2>
      <div class="form">
        <div class="row three">
          <div class="field"><label>Fecha</label><input id="plan_date" type="date" value="${escapeAttr(nowISODate())}" /></div>
          <div class="field"><label>Título</label><input id="plan_title" placeholder="Ej: Date night en casa" /></div>
          <div class="field"><label>Quién lo arma</label><select id="plan_who">${partnerOptions}</select></div>
        </div>
        <div class="field"><label>Plan</label><textarea id="plan_text" placeholder="Pasos, horarios, reservas..."></textarea></div>
        <div class="field"><label>Tags (coma)</label><input id="plan_tags" placeholder="comida, sorpresa, chill" /></div>
        <button class="btn primary" id="btnAddPlan">Agregar</button>
      </div>

      <div class="list">${items}</div>
    `;
  }

  function renderGoals(){
    const list=state.data.goals;
    const items=list.length ? list.map(x=>`
      <div class="item">
        <div class="top">
          <div>
            <div class="name">${escapeHtml(x.title)} <span class="chip">${escapeHtml(x.status)}</span></div>
            <div class="meta">${escapeHtml(x.category||"—")} • Objetivo: ${escapeHtml(x.targetDate?formatDate(x.targetDate):"—")}</div>
          </div>
          <div class="btns">
            <button class="btn danger" data-del="goal" data-id="${x.id}">Borrar</button>
          </div>
        </div>
        ${x.note?`<div class="note">${escapeHtml(x.note)}</div>`:""}
      </div>`).join("") : `<p class="small">Aún no hay metas. Agrega la primera arriba.</p>`;

    return `
      <h2>Metas</h2>
      <p>Metas con estado, categoría y fecha objetivo.</p>
      <div class="form">
        <div class="row two">
          <div class="field"><label>Meta</label><input id="goal_title" placeholder="Ej: viajar 2 veces al año" /></div>
          <div class="field">
            <label>Categoría</label>
            <select id="goal_cat">
              <option value="Viajes">Viajes</option>
              <option value="Finanzas">Finanzas</option>
              <option value="Salud">Salud</option>
              <option value="Casa">Casa</option>
              <option value="Comunicación">Comunicación</option>
              <option value="Diversión" selected>Diversión</option>
              <option value="Otro">Otro</option>
            </select>
          </div>
        </div>
        <div class="row two">
          <div class="field"><label>Fecha objetivo</label><input id="goal_target" type="date" /></div>
          <div class="field">
            <label>Estado</label>
            <select id="goal_status">
              <option value="Pendiente" selected>Pendiente</option>
              <option value="En progreso">En progreso</option>
              <option value="Lograda">Lograda</option>
              <option value="Pausada">Pausada</option>
            </select>
          </div>
        </div>
        <div class="field"><label>Nota</label><textarea id="goal_note" placeholder="Qué hay que hacer..."></textarea></div>
        <button class="btn primary" id="btnAddGoal">Agregar</button>
      </div>

      <div class="list">${items}</div>
    `;
  }

  function renderNotes(){
    const list=state.data.notes;
    const items=list.length ? list.map(x=>`
      <div class="item">
        <div class="top">
          <div>
            <div class="name">${escapeHtml(x.title||"Nota")} ${x.tag?`<span class="chip">${escapeHtml(x.tag)}</span>`:""}</div>
            <div class="meta">${escapeHtml(x.createdAt?new Date(x.createdAt).toLocaleString():"")}</div>
          </div>
          <div class="btns">
            <button class="btn danger" data-del="note" data-id="${x.id}">Borrar</button>
          </div>
        </div>
        ${x.body?`<div class="note">${escapeHtml(x.body)}</div>`:""}
      </div>`).join("") : `<p class="small">No hay notas aún.</p>`;

    return `
      <h2>Notas</h2>
      <p>Ideas rápidas: restaurantes, películas, regalos, etc.</p>
      <div class="form">
        <div class="row two">
          <div class="field"><label>Título</label><input id="note_title" placeholder="Ej: lista de restaurantes" /></div>
          <div class="field"><label>Etiqueta</label><input id="note_tag" placeholder="comida / película / regalo" /></div>
        </div>
        <div class="field"><label>Contenido</label><textarea id="note_body" placeholder="Escribe aquí..."></textarea></div>
        <button class="btn primary" id="btnAddNote">Agregar</button>
      </div>

      <div class="list">${items}</div>
    `;
  }

  function renderBackup(){
    return `
      <h2>Backup</h2>
      <p>Exporta e importa tus datos (importar reemplaza lo actual).</p>
      <div class="section">
        <div class="list">
          <div class="item">
            <div class="top">
              <div><div class="name">⬇️ Exportar datos</div><div class="meta">Descarga un .json con todo.</div></div>
              <button class="btn primary" id="btnExport2">Exportar</button>
            </div>
          </div>
          <div class="item">
            <div class="top">
              <div><div class="name">⬆️ Importar datos</div><div class="meta">Sube un backup .json.</div></div>
              <button class="btn" id="btnImport2">Importar</button>
            </div>
          </div>
          <div class="item">
            <div class="top">
              <div><div class="name">🧹 Reset completo</div><div class="meta">Borra datos + PIN del dispositivo.</div></div>
              <button class="btn danger" id="btnResetAll">Reset</button>
            </div>
          </div>
        </div>
        <div class="small">Para instalar como app: GitHub Pages (HTTPS) → Safari → Compartir → Agregar a pantalla de inicio.</div>
      </div>
    `;
  }

  function renderMain(){
    switch(state.activeTab){
      case "home": return renderHome();
      case "travels": return renderTravels();
      case "dates": return renderDates();
      case "goals": return renderGoals();
      case "notes": return renderNotes();
      case "backup": return renderBackup();
      default: return renderHome();
    }
  }

  function render(){
    $("#app").innerHTML = `
      <header class="topbar">
        <div class="topbar-inner">
          <div class="brand">
            <div class="logo" aria-hidden="true"><span>♡</span></div>
            <div class="title">
              <b>M&amp;D</b>
              <small>${escapeHtml(state.data.meta.partners.a)} + ${escapeHtml(state.data.meta.partners.b)}</small>
            </div>
          </div>
          <div class="actions">
            <button class="btn" id="btnLock" title="Bloquear">🔒</button>
            <button class="btn" id="btnExport" title="Exportar">⬇️</button>
            <button class="btn" id="btnImport" title="Importar">⬆️</button>
          </div>
        </div>
      </header>

      <div class="wrap">
        <div class="grid">
          <aside class="card">
            <h2>Resumen</h2>
            <div class="kpi">
              <div class="pill">📅 <b>${daysTogether(state.data.meta.startDate)}</b>&nbsp;días juntos</div>
              <div class="pill">🗓️ Desde&nbsp;<b>${formatDate(state.data.meta.startDate)}</b></div>
            </div>

            <div class="section">
              <div class="tabs">
                ${navTab("home","Home")}
                ${navTab("travels","Viajes")}
                ${navTab("dates","Dates")}
                ${navTab("goals","Metas")}
                ${navTab("notes","Notas")}
                ${navTab("backup","Backup")}
              </div>
            </div>

            <div class="section">
              <h2>Ajustes rápidos</h2>
              <div class="form">
                <div class="row two">
                  <div class="field"><label>Nombre de Martina</label><input id="nameA" value="${escapeAttr(state.data.meta.partners.a)}" /></div>
                  <div class="field"><label>Nombre de Diego</label><input id="nameB" value="${escapeAttr(state.data.meta.partners.b)}" /></div>
                </div>
                <div class="field">
                  <label>Fecha inicio (contador)</label>
                  <input id="startDate" type="date" value="${escapeAttr(state.data.meta.startDate)}" />
                  <div class="small">Por defecto: 23-01-2026.</div>
                </div>
                <button class="btn primary" id="btnSaveSettings">Guardar</button>
              </div>
            </div>
          </aside>

          <main class="card">
            ${renderMain()}
          </main>
        </div>

        <div class="footer-hint">🔐 Privado: todo queda en este dispositivo. En “Backup” puedes exportar/importar.</div>
      </div>
    `;
    wire();
  }

  // ---------- modal PIN ----------
  function showModal(html){
    const backdrop=document.createElement("div");
    backdrop.className="modal-backdrop";
    backdrop.innerHTML = `<div class="modal">${html}</div>`;
    document.body.appendChild(backdrop);
    return backdrop;
  }
  function closeModal(backdrop){ backdrop?.remove(); }

  function pinInputsTemplate(){
    return `<div class="pin">
      <input inputmode="numeric" maxlength="1" pattern="[0-9]*" data-pin="0" />
      <input inputmode="numeric" maxlength="1" pattern="[0-9]*" data-pin="1" />
      <input inputmode="numeric" maxlength="1" pattern="[0-9]*" data-pin="2" />
      <input inputmode="numeric" maxlength="1" pattern="[0-9]*" data-pin="3" />
    </div>`;
  }
  function wirePinInputs(backdrop){
    const inputs=$$("[data-pin]", backdrop);
    inputs.forEach((inp, idx)=>{
      inp.addEventListener("input", ()=>{
        inp.value = (inp.value||"").replace(/\D/g,"").slice(0,1);
        if(inp.value && idx<3) inputs[idx+1].focus();
      });
      inp.addEventListener("keydown", (e)=>{
        if(e.key==="Backspace" && !inp.value && idx>0) inputs[idx-1].focus();
      });
    });
    setTimeout(()=>inputs[0]?.focus(), 50);
  }
  function readPin(backdrop){
    return $$("[data-pin]", backdrop).map(i=>i.value||"").join("");
  }

  async function ensureUnlocked(){
    const existing = localStorage.getItem(PIN_KEY);
    if(!existing){
      const bd = showModal(`
        <h3>Crea tu PIN (4 dígitos)</h3>
        <p>Este PIN quedará guardado en este dispositivo.</p>
        ${pinInputsTemplate()}
        <div class="modal-actions">
          <button class="btn primary" id="createPin">Crear</button>
        </div>
        <div class="small">Tip: si lo olvidas, puedes hacer Reset en “Backup”.</div>
      `);
      wirePinInputs(bd);
      $("#createPin", bd).addEventListener("click", async ()=>{
        const pin=readPin(bd);
        if(!/^\d{4}$/.test(pin)) return toast("PIN inválido");
        localStorage.setItem(PIN_KEY, await pinHash(pin));
        closeModal(bd);
        state.unlocked=true;
        render();
        toast("PIN creado");
      });
      return;
    }
    const bd = showModal(`
      <h3>Ingresa tu PIN</h3>
      <p>Para abrir tu M&D.</p>
      ${pinInputsTemplate()}
      <div class="modal-actions">
        <button class="btn primary" id="unlock">Entrar</button>
      </div>
    `);
    wirePinInputs(bd);
    $("#unlock", bd).addEventListener("click", async ()=>{
      const pin=readPin(bd);
      if(!/^\d{4}$/.test(pin)) return toast("PIN inválido");
      if(await pinHash(pin) !== localStorage.getItem(PIN_KEY)){
        return toast("PIN incorrecto");
      }
      closeModal(bd);
      state.unlocked=true;
      render();
      toast("Bien :)");
    });
  }

  function lock(){
    state.unlocked=false;
    $("#app").innerHTML="";
    ensureUnlocked();
  }

  // ---------- export/import/reset ----------
  function exportData(){
    const payload = JSON.stringify(state.data, null, 2);
    const blob = new Blob([payload], {type:"application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href=url;
    a.download=`couple-planner-backup-${nowISODate()}.json`;
    a.click();
    setTimeout(()=>URL.revokeObjectURL(url), 500);
    toast("Backup descargado");
  }

  function importData(){
    const inp=document.createElement("input");
    inp.type="file";
    inp.accept="application/json";
    inp.onchange=()=>{
      const file=inp.files?.[0];
      if(!file) return;
      const reader=new FileReader();
      reader.onload=()=>{
        try{
          const data = JSON.parse(reader.result);
          state.data = data;
          saveData(state.data);
          toast("Importado");
          render();
        }catch{
          toast("Archivo inválido");
        }
      };
      reader.readAsText(file);
    };
    inp.click();
  }

  function resetAll(){
    if(!confirm("¿Reset completo? Esto borra datos + PIN en este dispositivo.")) return;
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(PIN_KEY);
    localStorage.removeItem(PIN_SALT_KEY);
    state.data = defaultData();
    toast("Reseteado");
    lock();
  }

  // ---------- wiring ----------
  function wire(){
    // tabs
    $$(".tab[data-tab]").forEach(b => b.addEventListener("click", ()=>{
      state.activeTab=b.dataset.tab;
      render();
    }));
    // summary goto
    $$("[data-goto]").forEach(b => b.addEventListener("click", ()=>{
      state.activeTab=b.dataset.goto;
      render();
    }));
    // lock/export/import
    $("#btnLock")?.addEventListener("click", lock);
    $("#btnExport")?.addEventListener("click", exportData);
    $("#btnImport")?.addEventListener("click", importData);
    $("#btnExport2")?.addEventListener("click", exportData);
    $("#btnImport2")?.addEventListener("click", importData);
    $("#btnResetAll")?.addEventListener("click", resetAll);

    // settings
    $("#btnSaveSettings")?.addEventListener("click", ()=>{
      state.data.meta.partners.a = ($("#nameA").value||"").trim() || "Martina";
      state.data.meta.partners.b = ($("#nameB").value||"").trim() || "Diego";
      state.data.meta.startDate = $("#startDate").value || START_DATE_DEFAULT;
      saveData(state.data);
      toast("Guardado");
      render();
    });

    // travel subtabs
    $$("[data-subtrav]").forEach(b=>b.addEventListener("click", ()=>{
      state.subTab.travels=b.dataset.subtrav;
      state.activeTab="travels";
      render();
    }));
    // dates subtabs
    $$("[data-subdates]").forEach(b=>b.addEventListener("click", ()=>{
      state.subTab.dates=b.dataset.subdates;
      state.activeTab="dates";
      render();
    }));

    // add travel
    $("#btnAddTravel")?.addEventListener("click", ()=>{
      const sub=$("#btnAddTravel").dataset.sub;
      const dest=$("#trav_dest").value.trim();
      if(!dest) return toast("Escribe un destino");
      state.data.travels[sub].push({
        id: uuid(),
        dest,
        priority: $("#trav_priority").value,
        when: ($("#trav_when").value||"").trim(),
        budget: ($("#trav_budget").value||"").trim(),
        who: $("#trav_who").value,
        note: ($("#trav_note").value||"").trim(),
        createdAt: new Date().toISOString()
      });
      saveData(state.data);
      toast("Destino agregado");
      render();
    });

    // add idea
    $("#btnAddIdea")?.addEventListener("click", ()=>{
      const title=$("#idea_title").value.trim();
      if(!title) return toast("Escribe una idea");
      state.data.dates.ideas.push({
        id: uuid(),
        title,
        type: $("#idea_type").value,
        budget: ($("#idea_budget").value||"").trim(),
        when: ($("#idea_when").value||"").trim(),
        by: $("#idea_by").value,
        note: ($("#idea_note").value||"").trim(),
        createdAt: new Date().toISOString()
      });
      saveData(state.data);
      toast("Idea agregada");
      render();
    });

    // add plan
    $("#btnAddPlan")?.addEventListener("click", ()=>{
      state.data.dates.dayByDay.push({
        id: uuid(),
        date: $("#plan_date").value || nowISODate(),
        title: ($("#plan_title").value||"").trim(),
        plan: ($("#plan_text").value||"").trim(),
        who: $("#plan_who").value,
        tags: ($("#plan_tags").value||"").split(",").map(s=>s.trim()).filter(Boolean),
        createdAt: new Date().toISOString()
      });
      saveData(state.data);
      toast("Plan agregado");
      render();
    });

    // add goal
    $("#btnAddGoal")?.addEventListener("click", ()=>{
      const title=$("#goal_title").value.trim();
      if(!title) return toast("Escribe una meta");
      state.data.goals.push({
        id: uuid(),
        title,
        category: $("#goal_cat").value,
        targetDate: $("#goal_target").value || "",
        status: $("#goal_status").value,
        note: ($("#goal_note").value||"").trim(),
        createdAt: new Date().toISOString()
      });
      saveData(state.data);
      toast("Meta agregada");
      render();
    });

    // add note
    $("#btnAddNote")?.addEventListener("click", ()=>{
      const title = ($("#note_title").value||"").trim();
      const tag = ($("#note_tag").value||"").trim();
      const body = ($("#note_body").value||"").trim();
      if(!title && !body) return toast("Escribe algo");
      state.data.notes.push({
        id: uuid(),
        title,
        tag,
        body,
        createdAt: new Date().toISOString()
      });
      saveData(state.data);
      toast("Nota agregada");
      render();
    });

    // deletes (event delegation)
    $$("[data-del]").forEach(b=>{
      b.addEventListener("click", ()=>{
        const type=b.dataset.del;
        const id=b.dataset.id;
        if(type==="travel"){
          const sub=b.dataset.sub;
          state.data.travels[sub] = state.data.travels[sub].filter(x=>x.id!==id);
        } else if(type==="idea"){
          state.data.dates.ideas = state.data.dates.ideas.filter(x=>x.id!==id);
        } else if(type==="plan"){
          state.data.dates.dayByDay = state.data.dates.dayByDay.filter(x=>x.id!==id);
        } else if(type==="goal"){
          state.data.goals = state.data.goals.filter(x=>x.id!==id);
        } else if(type==="note"){
          state.data.notes = state.data.notes.filter(x=>x.id!==id);
        }
        saveData(state.data);
        toast("Borrado");
        render();
      });
    });
  }

  // ---------- boot ----------
  if("serviceWorker" in navigator){
    navigator.serviceWorker.register("./service-worker.js").catch(()=>{});
  }

  // start locked
  ensureUnlocked();
})();
