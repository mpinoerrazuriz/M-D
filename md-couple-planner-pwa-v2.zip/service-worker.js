const CACHE_NAME="couple-planner-pwa-v1";
const ASSETS=["./","./index.html","./styles.css","./app.js","./manifest.json","./icon-192.png","./icon-512.png"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()))});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.map(k=>k===CACHE_NAME?null:caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener("fetch",e=>{
  e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).then(res=>{
    try{const url=new URL(e.request.url);if(e.request.method==="GET"&&url.origin===self.location.origin){caches.open(CACHE_NAME).then(c=>c.put(e.request,res.clone()))}}catch(_){}
    return res;
  }).catch(()=>cached)));
});
